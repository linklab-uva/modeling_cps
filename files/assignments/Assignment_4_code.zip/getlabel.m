function y = getlabel(th,dummy,pass)
%{ 
Function description:
Given a parameter vector, this function simulates the model specified by the
model_strucutre function to return a vector of predictied model outputs. 

Inputs: 
        th:     the parameter vector, provides by the parameter_estimation
        fucntion.
        pass:   the structure with all relevant details about the model
        states, and inputs.
        dummy:  debugging variable - can be ignored or used to pass any
        relevant data for debugging the function. 

Output: 
        y:  The vector of predicted values. 

This function to run the simulation with relative parameter values
th and input data U.

%}

% global variables can be shared accross functions without having to pass
% them through funciton calls. The ones shwon here are being used for
% plotting and debugging purposes only, and not for estimation. 
global dsystem;
global Yall;
global TH;

% The timestep (in seconds) of the discretized state-space model should match the
% sampling rate of the data. 
timestep = 120; % 'Change this if required'


shift_val = 0.8;    % discretization parameter. 
U = pass.U;
PARANOM = pass.paranom;
nstates=pass.nstates;
ninputs=pass.ninputs;
ndata = pass.ndata;
xinter = pass.xinter;   

paralist = cat(2,PARANOM.rvalues,PARANOM.cvalues);

TH = paralist.*(1 + sin(th)*shift_val);


% Obtain the state-space matrices, for a given value of the parameter
% vetor. 
[A,B,C,D] = model_structure('Pass the correct arguments');

% Create a MATLAB state-space model object.
sys = ss('Pass the correct arguments to this function');

% Model discretization.
sysd = c2d(sys,timestep);
Ad = sysd.A;    Bd = sysd.B;    
Cd = sysd.C;    Dd = sysd.D;

% dsystem is just used for debuggin purposes- For example matrix inversion
% problems or inconsistent Jacobians 
dsystem.Ad = Ad;
dsystem.Bd = Bd;
dsystem.Cd = Cd;
dsystem.Dd = Dd;

% Use the discrete state space parameters to predict the model response for
% each training data sample. Remember, all we need to predict Y(i) is the
% intial state x(0) and the inputs from u(0) till u(i). 
Yall=zeros(ndata,nstates);
for i = 1:ndata
    xinter = 'Simulate the model states';
    Yall(i,:) = 'Simulate the model output';
end

y = Yall(:,end);

end

