function [paranom,surfaces] = construction()

% Goal:
% Get familiar with zone construction
% Get familair with IDF files
% Parameter details and calclulation of the nominal values.

%{
Function Name: construction.m
Input arguments:
    - None
Outputs:
    paranom: A struct of nominal values with two fields
        - rvalues: thermal conductance nominal values.
        - cvalues: thermal capacity nominal values.
    surfaces: A struct with two fields:
        - areas: calculated areas of different zone surfaces
        - sol_abs: coefficient of irradiance absorpiton or transmission, where applicable.
%}

%{

! Floor Area:        463.6 m2 (5000 ft2)
! Number of Stories: 1
!
! Zone Description Details:
!
!      (0,15.2,0)                      (30.5,15.2,0)
!           _____   ________                ____
!         |\     ***        ****************   /|
!         | \                                 / |
!         |  \                 (26.8,11.6,0) /  |
!         *   \_____________________________/   *
!         *    |(3.7,11.6,0)               |    *
!         *    |                           |    *
!         *    |                           |    *
!         *    |               (26.8,3.7,0)|    *
!         *    |___________________________|    *
!         *   / (3.7,3.7,0)                 \   *
!         |  /                               \  |
!         | /                                 \ |
!         |/___******************___***________\|
!          |       Overhang        |   |
!          |_______________________|   |   window/door = *
!                                  |___|
!
!      (0,0,0)                            (30.5,0,0)


%}

% Compute all required surface areas based on zone geometry from the IDF
% This has already been filled out for you, considering the trapizoidal
% shape of the zone. All areas are in sq meters.

Aw = (13.7*1.2) ;           % window area m^2
Add = (2.1*2.1) ;           % door area m^2
Abk = (30.5*2.4)-Aw-Add;    % back/outdoor external wall
Ai32 = (5.16*2.4);          % internal wall b/w zone 3 & 2
Ai34 = Ai32;                % internal wall b/w zone 3 & 4
Ai35 = (23.1*2.4);          % internal wall b/w zone 3 & 5
Ait = Ai32+Ai34+Ai35;       % total internal wall surface area
Af = 0.5*3.6*(30.5+23.1);   % floor area
Ac = Af;                    % ceiling area = floor area


% For each lumped surface compute the thermal conductance and thermal capacity.
% The computed values will be used as the nominal parameter values for the
% on-linear paramter estimation. 


% ===== Back external wall ========
% The layers from outside to inside are indicated below:
%{

Outside Air Temp ---| WD01 | PW03 | IN02 | GP01 |--- Zone temperature

%}


% Outside layer material: WD01
l_o=1.9099999E-02;      % !- Thickness {m}
k_o=0.1150000;          % !- Conductivity {W/m-K}
d_o=513.0000;           % !- Density {kg/m3}
cp_o=1381.000;          % !- Specific Heat {J/kg-K}

% layer 2 material: PW03
l_1=1.2700000E-02;      % !- Thickness {m}
k_1=0.1150000;          % !- Conductivity {W/m-K}
d_1=545.0000;           % !- Density {kg/m3}
cp_1=1213.000;          % !- Specific Heat {J/kg-K}

% layer 3 material: IN02
l_2=9.0099998E-02;      % !- Thickness {m}
k_2=4.3000001E-02;      % !- Conductivity {W/m-K}
d_2=10.00000;           % !- Density {kg/m3}
cp_2=837.0000;          % !- Specific Heat {J/kg-K}


% layer 4 material: GP01
l_3=1.2700000E-02;      % !- Thickness {m}
k_3=0.1600000;          % !- Conductivity {W/m-K}
d_3=801.0000;           % !- Density {kg/m3}
cp_3=837.0000;          % !- Specific Heat {J/kg-K}

% Compute the nominal value of the thermal conductance and capacitance parameter.

Re = (1/Abk)*((l_o/k_o)+(l_1/k_1)+(l_2/k_2)+(l_3/k_3));
Ce = 0.5*Abk*((d_o*cp_o*l_o)+(d_1*cp_1*l_1)+(d_2*cp_2*l_2)+(d_3*cp_3*l_3));

% ===== Interior walls ========
% The layers from outside to inside are indicated below:
%{

Neighboring zone(s) air temp ---| GP02 | AL21 | GP02 |--- Zone temperature

%}

% layer 1 material: GP02
l_0=1.5900001E-02;      % !- Thickness {m}
k_0=0.1600000;          % !- Conductivity {W/m-K}
d_0=801.0000;           % !- Density {kg/m3}
cp_0=837.0000;          % !- Specific Heat {J/kg-K}

% layer 2 material: AL21 (no thermal mass)
r_2=0.1570000;%               !- Thermal Resistance {m2-K/W}

% layer 3 same as layer 1

% Compute the nominal value of the thermal conductance and capacitance parameter.
Ri = (1/Ait)*(2*(l_0/k_0)) + r_2/Ait;
Ci = Ait*(2*d_0*l_0*cp_0);

% ===== Floor ========
% The layers from outside to inside are indicated below:
%{

Ground Temp ---| CC03 |--- Zone temperature

%}

% layer 1 material: CC03
l_0=0.1016000;          % !- Thickness {m}
k_0=1.310000;           % !- Conductivity {W/m-K}
d_0=2243.000;           % !- Density {kg/m3}
cp_0=837.0000;          % !- Specific Heat {J/kg-K}

% Compute the nominal value of the thermal conductance and capacitance parameter.
Rf = (1/Af)*(l_0/k_0);
Cf = d_0*l_0*cp_0*Af;
    
% ===== Ceiling ========
% The ceiling surface of the zone is not connected to the roof directly.
% There is a return air plenum in between. We can consider the return
% plenum as anoter zone in itself and model the interaction with the plenum
% directly. This helps simply the zone modeling further. The thermal
% conductance for the celing layer is given below.

r_0=0.652259290;        % !- Thermal Resistance {m2-K/W}

% Compute the nominal value of the thermal conductance parameter.
Rc = (1/Ac)*(r_0);

% ===== Window and door ========
% Double layers surfaces. Each layer is the material: CLEAR 3mm 

l_0=0.003;              % !- Thickness {m}
k_0=0.9;                % !- Conductivity {W/m-K}

% Compute the nominal value of the thermal conductance parameter (door and
% window combined into one parameter.)
Rw = (2*l_0)/(k_0*Aw);
rd = (2*l_0)/(k_0*Add);
Rw = Rw+rd;

% % ===== Air properties ========

Roair = 15;             % W/m2K Outside air thermal resistance.
Riair = 3.076;          % W/m2K Internal air thermal resistance.
cpair = 1005;           % J/kg-K Specific heat
dair = 1.205;           % kg/m3 Density
vair = 239.247;         % m3 Volumne
Cair = dair*cpair*vair; % J/K Thermal capacitance of the zone air.


% perturb = 0.1:0.1:2;
% fiterror = zeros(1,length(perturb));
% predicterror = zeros(1,length(perturb));

% Construct a structure with the nominal values of all the parameters:

paranom = struct('rvalues',[],'cvalues',[]);
% rvalues (K/W)
paranom.rvalues(1) = 1/(Abk*Roair);
paranom.rvalues(2) = Re;                % 0.5
paranom.rvalues(3) = 1/(Abk*Riair);
paranom.rvalues(4) = 0.7*Ri;
paranom.rvalues(5) = 1/(Ait*Riair);
paranom.rvalues(6) = Rf;
paranom.rvalues(7) = 1/(Af*Riair);
paranom.rvalues(8) = 1.1*Rw;            % 1.7
paranom.rvalues(9) = 1.1*Rc;

% cvalues (J/K)
paranom.cvalues(1) = 1.1*Ce;
paranom.cvalues(2) = 0.9*Ce;
paranom.cvalues(3) = 0.7*Ci;            %  0.8
paranom.cvalues(4) = Cf;                %
paranom.cvalues(5) = 1.2*Cair;



surfaces=struct('areas',[],'sol_abs',[]);
surfaces.areas(1)=Abk;                  % external wall
surfaces.sol_abs(1) = 0.78;             % external wall
end

















    

