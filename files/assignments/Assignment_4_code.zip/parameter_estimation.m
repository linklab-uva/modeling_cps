close all;
clear all;
clc;


global dsystem;
global Yall;
global TH;

dsystem.init = 0;

%% Construction details and calclulation of the nominal values.

%Obtain nominal parameters structure and some zone construction information
[paranom,surfaces]=construction(); % NO input arguments should be provided

%% Load the building dataset.
%{
Read and store building input-output data

More about the data:

Column# | Input data stream of interest.
3   |   Ground temperature (C)
2   |   Outside ambient temp (c)
4   |   Total internal radiative gain (W)
6   |   Total internal convective gain (W) 
14  |   solar radiation on external wall (W)
10  |   solar radiation transmitted through window +door (W)
9   |   other equipment (W)
23  |   SPACE2-1 temp (C)
25  |   SPACE3-1 temp (C)
26  |   SPACE4-1 temp (C)
27  |   SPACE5-1 temp (C)
22  |   plenum temp (C)
%}

%alldata = readtrainingdata('5ZoneAirCooled_altmod.csv'); % refer to this file to know more about all the columns of data.mat
load('data.mat');
alldata(1,:)=[];
alldata(:,12) = (alldata(:,12)+alldata(:,20)+alldata(:,21))/3; % average indoor temperatures of all neighboring zones


% Load date/time schedule info:
% This is usedful for plotting as well as separating weekend and weekday
% schedules. 
load('training_dates.mat');
dateinfo=datenum(training_dates(1:end));

% total number of parameters
npara = length(paranom.rvalues)+length(paranom.cvalues);
% total number of training data samples
ndata = length(alldata); 

%% Split into training and testing datasets. 
% specify the fraction of data to be used for model training (parameter
% estimation)
ntrain = floor(0.7*ndata);
ntest = ndata - ntrain;

% number of states and inputs of the state-space model.
nstates = 5;
ninputs = 7;

% Training data structure
U=zeros(ntrain,ninputs);         

U(:,1)=alldata(1:ntrain,2);     % ta: outside ambient temperature.
U(:,2)=alldata(1:ntrain,3);     % tg: ground slab temp.
U(:,3)=alldata(1:ntrain,22);    % tp: plenum temperature. 
U(:,4)=alldata(1:ntrain,12);    % <tiw>: Average indoor interaction temp.
U(:,5)=alldata(1:ntrain,15);    % qsole: External solar irradiation.
U(:,6)=alldata(1:ntrain,8);     % qgain: Internal heat gains.
U(:,7)=alldata(1:ntrain,9);     % qcool: Cooling rate. 

Y=alldata(1:ntrain,25);         % SPACE3-1 temp (output)

% Get states (These are not used for parameter estimation but can be used later for model validation.)
X=zeros(ntrain,5);
X(:,1)=alldata(1:ntrain,14);
X(:,2)=alldata(1:ntrain,13);
X(:,3)=(alldata(1:ntrain,12)+alldata(1:ntrain,20)+alldata(1:ntrain,21))/3;
X(:,4)=alldata(1:ntrain,19);


%% Parameter estimation

% The strucutre pass describes all the characteriestics of the state-sapce
% model and parameter estimation. This structure is used to 'pass' this
% info between functions. 
pass.U = U;
pass.npara=npara;
pass.ndata=ntrain;
pass.paranom=paranom;
pass.nstates=nstates;
pass.ninputs=ninputs;

% You may need to change the inital states values based on the model you
% have.
pass.xinter =[alldata(2,14),alldata(2,13),((alldata(2,12)+alldata(2,20)+alldata(2,21))/3),alldata(2,19),alldata(2,25)]'; 


% Set up non-linear regression.

norm_min = 10000;        % inital value of the sum of squares value function. 
n_start = 10;            % Option for multi-start (useful for random or perturbed inital values).

% Specify the option set for the non-linear parameter estimation function:
options = statset('specify options for the estimation algorithm here');

% Easier to work with an array of vector rather than the paranom struture. 
% The paralist is the vector of parameter values (the vector p that is
% passed to the model_structure.m function).
paralist = cat(2,paranom.rvalues,paranom.cvalues);
th0 = paralist;

%{
For a multistart parameter search, we may want to constratint the random 
start points to fall within a range of the nominal parameter values. For
instance contraint the search between [0.75*paralist, 1.25*paralist] 
This will limit the search within a bounded region around the nominal parameter values. 
Write the script to specify the lower (lb) and upper (ub) bounds on the
parameter values. 
Remember to ensure that the estimation function you are using can handle constrainted paramer optimization. 
%}

% % Uncomment and specify bounds below:
% lb = 0;
% ub = 0;

% % Multi-start scheme. Uncoment below to enable a multi-start search if
% % using nlinfit.
% for i = 1:n_start   
%     th0 = lb + ((ub-lb)*rand(1,1));
% 
%     [th,R,J,COVB,mse] = nlinfit(U,Y,@(th,U)getlabel(th,U,pass),th0,options);
% 
%     if (norm(R)/sqrt(ntrain) < norm_min)
%         norm_min = norm(R)/sqrt(ntrain);
%         th_final = th; % final parameters value
%     end
%     disp(['regression ', num2str(i),' has a RMSE of ', num2str(norm_min)]);
% end

[th,R,J,COVB,mse] = nlinfit('Fill out all the arguments of nlinfit');
 
% Useful for debugging to display the jacobian, covariance, and variance of
% the parameter matrix. 
% disp(['Final regression function jacobian ', num2str(J)]);
% disp(['Final regression covariance of parameters ', num2str(COVB)]);
% disp(['Final regression variance of error ', num2str(mse)]);

%% Model Evaluation
ypred = getlabel(th_final,[],pass);

plot(1:ntrain,ypred,1:ntrain,Y);legend('Predicted','Measured');
fit = goodnessOfFit('Fill this out');
str = sprintf('Training data NRMSE %f',fit);
title(str);

% Evaluate the model on unseen test-set data.

Ut=zeros(ntest,7);                  % testing data structure

% Make sure the columns and the ordering of the columns in the test data structure is compatible with
% your model structure. Hint: the test data structure should be similar to
% the training data structure. 

Ut(:,1)=alldata(ntrain+1:end,2);    % ta
Ut(:,2)=alldata(ntrain+1:end,3);    % tg
Ut(:,3)=alldata(ntrain+1:end,22);   % tp
Ut(:,4)=alldata(ntrain+1:end,12);   % <tiw>
Ut(:,5)=alldata(ntrain+1:end,15);   % qsole
Ut(:,6)=alldata(ntrain+1:end,8);    % qgain
Ut(:,7)=alldata(ntrain+1:end,9);    % qcool

Yt=alldata(ntrain+1:end,25);        % zone temp (output)

pass.U = Ut;
pass.npara=npara;
pass.ndata=ntest;
pass.paranom=paranom;
pass.nstates=nstates;
pass.ninputs=ninputs;
pass.xinter =[alldata(ntrain+1,14),alldata(ntrain+1,13),((alldata(ntrain+1,12)+alldata(ntrain+1,20)+alldata(ntrain+1,21))/3),alldata(ntrain+1,19),alldata(ntrain+1,25)]'; 

% get predictions on the unseen dataset
ym = getlabel(th_final,[],pass);

prediction_error = goodnessOfFit(ym,Yt,'NRMSE');
figure();
plot(1:ntest,ym,1:ntest,Yt);
legend('Predicted','Measured');
str = sprintf('Test data NRMSE = %f',prediction_error);
title(str);
disp(prediction_error);
%


%% Plots for debugging the model fit. 

% figure();
% plot(1:ntrain,Yall(:,1),1:ntrain,X(:,1));legend('Predicted','Measured');
% fit_error1 = goodnessOfFit(X(1:ntrain,1),Yall(1:ntrain,1),'NRMSE');
% str = sprintf('Te1 NRMSE = %f',fit_error1);
% title(str);
% disp(['Te1 NRMSE ',num2str(fit_error1)]);
% 
% figure();
% plot(1:ntrain,Yall(:,2),1:ntrain,X(:,2));legend('Predicted','Measured');
% fit_error2 = goodnessOfFit(X(1:ntrain,2),Yall(1:ntrain,2),'NRMSE');
% str = sprintf('Te2 NRMSE = %f',fit_error2);
% title(str);
% disp(['Te2 NRMSE ',num2str(fit_error2)]);
% 
% figure();
% plot(1:ntrain,Yall(:,3),1:ntrain,X(:,3));legend('Predicted','Measured');
% fit_error3 = goodnessOfFit(X(1:ntrain,3),Yall(1:ntrain,3),'NRMSE');
% str = sprintf('Ti NRMSE = %f',fit_error3);
% title(str);
% disp(['Ti NRMSE ',num2str(fit_error3)]);
% 
% figure();
% plot(1:ntrain,Yall(:,4),1:ntrain,X(:,4));legend('Predicted','Measured');
% fit_error4 = goodnessOfFit(X(1:ntrain,4),Yall(1:ntrain,4),'NRMSE');
% str = sprintf('Tf NRMSE = %f',fit_error4);
% title(str);
% disp(['Tf NRMSE ',num2str(fit_error4)]);
% 
% figure();
% bar((paranom.rvalues-TH(1:9))./paranom.rvalues);
% title('% change from nominal R values');
% 
% figure();
% bar((paranom.cvalues-TH(10:14))./paranom.cvalues);
% title('% change from nominal C values');




