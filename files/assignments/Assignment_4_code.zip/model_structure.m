function [A,B,C,D] = model_structure(p,nstates,ninputs)
%{

Input the A, B, C and D matrices for the state space model in terms of the parameters specified in paranom. 

Function Name: model_structure.m
Function Description: Given a vector of parameters, the function creates
the state transition (A), input (B), output (C), and feedforward (D)
matrices by specifying the non-zero elements in these matrices. 
Input arguments: 3
    - p: This is a vector of all the unknown parameters. For parameter identification we initialize the vector p using the nominal
    values computed in the paranom structure. 
    - nstates: Number of states in the model (from Worksheet 2)
    - ninputs: Number of inputs in the model (from Worksheet 2)
    
Outputs:
    Matrices A,B,C, and D with the correct dimentsions:
    dim(A) = nstates x nstates
    dim(B) = nstates x ninputs
    dim(C) = nstates x nstates
    dim(D) = nstates x ninputs

Notes:

The ordering of the parameters in the vector p depends on your model.
The template in this file uses the following assignment of the vector p. 
This is based on the paranom struct in the file construction_exercise.m
if you changed the structure in the construction.m solution file, then your
p vector assignements may vary (which is ok, as long as you use the correct
p vector elements to assign to the elements of A,B,C,and D matrices.

p(1)= paranom.rvalues(1) = 1/(Abk*Roair)
p(2)= paranom.rvalues(2) = Re                 
p(3)= paranom.rvalues(3) = 1/(Abk*Riair)
p(4)= paranom.rvalues(4) = Ri
p(5)= paranom.rvalues(5) = 1/(Ait*Riair)
p(6)= paranom.rvalues(6) = Rf
p(7)= paranom.rvalues(7) = 1/(Af*Riair)
p(8)= paranom.rvalues(8) = Rw
p(9)= paranom.rvalues(9) = Rc
p(10)= paranom.cvalues(1) = Ce
p(11)= paranom.cvalues(2) = Ce
p(12)= paranom.cvalues(3) = Ci            
p(13)= paranom.cvalues(4) = Cf                
p(14)= paranom.cvalues(5) = Cair

The assignment of non-zero elements of the A,B,C, and D will also depend on
the state variables, and the order in which the states appear. 

For the template in this function file, the following state vector 'x' is
assumed:

x = [Teo, Tei, Ti, Tf, Tz]
Teo: External wall outside temperature.
Tei: External wall inside temperature.
Ti: Internal wall temp.
Tf: Outside floor temp.
Tz: Zone temeprature.


%}

A = zeros(nstates);
B = zeros(nstates,ninputs);
C = eye(nstates);
D = zeros(nstates,ninputs);


A(1,1) = -(1/(p(1)*p(10)))-(1/(p(2)*p(10)));
A(1,2) = (1/(p(2)*p(10)));

A(2,1) = (1/(p(2)*p(11)));
A(2,2) = -(1/(p(2)*p(11)))-(1/(p(3)*p(11)));
A(2,5) = (1/(p(3)*p(11)));

A(3,3) = -(1/(p(4)*p(12)))-(1/(p(5)*p(12)));
A(3,5) = (1/(p(5)*p(12)));

A(4,4) = -(1/(p(6)*p(13)))-(1/(p(7)*p(13)));
A(4,5) = (1/(p(7)*p(13)));

A(5,2) = (1/(p(3)*p(14)));
A(5,3) = (1/(p(5)*p(14)));
A(5,4) = (1/(p(7)*p(14)));
A(5,5) = -(1/(p(3)*p(14)))-(1/(p(5)*p(14)))-(1/(p(7)*p(14)))-(1/(p(8)*p(14)))-(1/(p(9)*p(14)));


B(1,1) = (1/(p(1)*p(10)));
B(1,5) = 1/p(10);
B(3,4) = (1/(p(4)*p(12)));
B(4,2) = (1/(p(6)*p(13)));
B(5,1) = (1/(p(8)*p(14)));
B(5,3) = (1/(p(9)*p(14)));
B(5,6) = 1/p(14);
B(5,7) = 1/p(14);


end

