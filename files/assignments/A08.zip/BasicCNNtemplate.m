% Basic CNN implmentation of the example seen in the lectures
% Madhur Behl 2018
%
% Two image categories: O and X images
% Each image is single channel and 116 x 116 pixels. 
% 

% The Basic CNN consistes of:
% 3 convolutional layers with filter size of 10x10 px and 16-32-32 features
%
% 
%      1   'Input'            Image Input             116x116x1 images with 'zerocenter' normalization
%      2   'Conv1'            Convolution             16 10x10x1 convolutions with stride [1  1] and padding [4  4  4  4]
%      3   'ReLu1'            ReLU                    ReLU
%      4   'Pool1'            Max Pooling             5x5 max pooling with stride [2  2] and padding [0  0  0  0]
%      5   'Conv2'            Convolution             32 10x10 convolutions with stride [1  1] and padding [4  4  4  4]
%      6   'ReLu2'            ReLU                    ReLU
%      7   'Pool2'            Max Pooling             5x5 max pooling with stride [2  2] and padding [0  0  0  0]
%      8   'Conv3'            Convolution             32 10x10 convolutions with stride [1  1] and padding [2  2  2  2]
%      9   'ReLu3'            ReLU                    ReLU
%     10   'Pool3'            Max Pooling             3x3 max pooling with stride [2  2] and padding [0  0  0  0]
%     11   'FC'               Fully Connected         2 fully connected layer
%     12   'Softmax'          Softmax                 softmax
%     13   'Classification'   Classification Output   crossentropyex


%% Configure the execution of this file

% clear the workspace, close all exisitng figures, and clear the console
close all; clear variables; clear global; clc          

% It is possible to load a trained network from disk to save time when running the
% file, or perhaps load a network and resume training from those weights. 
% Set this flag to true to train the network.

doTraining              = true;

% Set these flags to inspect and plot the network (Note: optimized for screen resolution (1920x1200))
show.wrong_classified   = false;                         % wrong classified images
show.filter             = false;                         % filters(weights)
show.feature_maps       = true;                          % feature maps

%% Lets load and prep the data

% Load the file data for training the CNN
% Use imageDatastore for loading the two image categories
% The folder training_data must be present in the root directory from where
% this script is being run.

% ImageDatastore object manages a collection of image files, 
% where each individual image fits in memory, 
% but the entire collection of images does not necessarily fit.
% Here wer are directing MATLAB to the location of the folder that contains
% the training data. We also indicate that the folder contains two
% subfolders [circles, crosses] with images of type .bmp, and that the
% label for each of the images will be the name of the subfolder to which
% it belongs.

IMDS = imageDatastore('training_data','IncludeSubfolders',true,'FileExtensions','.bmp','LabelSource','foldernames'); 

example_image = readimage(IMDS,1);   % read one example image from the datastore.

% Uncomment the line below to display the example_image.
% imshow(example_image);

numChannels = size(example_image,3);                    % get color information - The images are single channel in this exercise.
numImageCategories = size(categories(IMDS.Labels),1);   % Two image categories in our dataset.

% Create the training and testing datasets. 
% Split ImageDatastore labels by proportions
training_propotion = 0.7;
[trainingDS,validationDS] = splitEachLabel(IMDS,training_propotion,'randomize'); 

LabelCntTr = countEachLabel(trainingDS);                        % load lable information
LabelCntVa = countEachLabel(validationDS);  

for cats=1:numImageCategories  % print out how many images we have for each category in Training
    fprintf('Training Data: %s\t%d\n',LabelCntTr.Label(cats),LabelCntTr.Count(cats));
end
for cats=1:numImageCategories  % print out how many images we have for each category in Validation
    fprintf('Validation Data: %s\t%d\n',LabelCntVa.Label(cats),LabelCntVa.Count(cats));
end

%% Setup of the CNN architecture.

if doTraining
    
  
    % Convolutional layer parameters
    filterSize = [10 10];
    numFilters = 16;
    
    % An image input layer inputs 2-D images to a network and applies data normalization.
    % The size of the layer is the same as the number of pixels in our
    % input images.
    inputLayer = imageInputLayer(size(example_image),'Name','Input');  % no data augmentation
    
    middleLayers = [
        % The first convolutional layer has a bank of numFilters filters of size filterSize. 
        % A symmetric padding of 4 pixels is added.
        convolution2dLayer(...)
        % Next add the ReLU layer:
        reluLayer('Name','ReLu1')
       % Follow it with a max pooling layer that has a 5x5 spatial pooling area
        % and a stride of 2 pixels. This down-samples the data dimensions.
        maxPooling2dLayer(...)
        
        % Repeat the 3 core layers to complete the middle of the network.
        % This time use 32 filters instead of 16.

        
        % Repeat the 3 core layers one more time
        % This time change symmetric padding to 2 for the convolution, and
        % the stride to 3 for the maxpoolinglayer.
   
        
        ];
    
    finalLayers = [
        
        % % Add a fully connected layer with the same number of neurons as
        % the number of image categories.
        fullyConnectedLayer(numImageCategories,'Name','FC')
        
        % Add the softmax loss layer and classification layer. 
        % The final layers use the output of the fully connected layer to compute the categorical
        % probability distribution over the image classes. During the training
        % process, all the network weights are tuned to minimize the loss over this
        % categorical distribution.
        softmaxLayer('Name','Softmax');
        classificationLayer('Name','Classification')
        ];
    
    layers = [
        inputLayer
        middleLayers
        finalLayers
        ];
    
    % Visualize the layer graph of the network
    lgraph = layerGraph(layers);
    plot(lgraph);

%% Train the Network
    %Initialize the first convolutional layer weights using 
    % normally distributed random numbers with standard deviation of 0.0001.
    % This helps improve the convergence of training.
    layers(2).Weights = 0.0001 * randn([filterSize numChannels numFilters]);
    
    % Set the network training options
    % Try Momentum option 0.1 and 0.9 - Which is Better ?
    % Try LearningRate 0.01, and 0.001 - What is the difference ?
    % Try 10-20 Maxepochs
    
    opts = trainingOptions('sgdm', ...
        'Momentum', 0, ...
        'InitialLearnRate', 0, ...
        'LearnRateSchedule', 'piecewise', ...
        'LearnRateDropFactor', 0.5, ...
        'LearnRateDropPeriod', 10, ...
        'L2Regularization', 0.004, ...
        'MaxEpochs', 0, ...        
        'MiniBatchSize', 64, ...    % 64 for Quadro 
        'Verbose', true,...
        'Plots','training-progress');
   
    % Train a network.
    rng('default');
    rng(123); % random seed
   
    XONet = trainNetwork(trainingDS, layers, opts);
    save('XONet.mat','XONet');
    
    % Retrain the network this time starting from the previous NN output as
    % the initial weights
    rng(123); % random seed
    XONet2 = trainNetwork(trainingDS, XONet.Layers, opts);
    save('XONet2.mat','XONet2');
else
    % Load pre-trained detector if doTraining was set to false.
    load('XONet.mat');
    load('XONet2.mat');
end


%% Test the performance of the NN

% test network performance on validation set
[labels,~] = classify(XONet, validationDS, 'MiniBatchSize', 128);

% calculate the confusion matrix. 
confMat = confusionmat(validationDS.Labels, labels);
confMat = bsxfun(@rdivide,confMat,sum(confMat,2));
fprintf('Performance on validation set \t\t\t%.4f\n',mean(diag(confMat)));

% test network performance of the re-trained NN on validation set
[labels,~] = classify(XONet2, validationDS, 'MiniBatchSize', 128);
confMat = confusionmat(validationDS.Labels, labels);
confMat = bsxfun(@rdivide,confMat,sum(confMat,2));
fprintf('Performance on validation set after retraining \t%.4f\n',mean(diag(confMat)));

%% Plot wrongly classsified images
if show.wrong_classified
    % % Search for wrong classified examples
    idx = find(validationDS.Labels~=labels);
    fprintf('We have %d/%d wrong classifications\n',length(idx),size(labels,1));
    
    for jj = 1:length(idx)
        img = readimage(validationDS,idx(jj));
        figh=figure(1);clf;
        set(figh,'Outerposition',[1,41,450,360]);
        imagesc(img),
        axis square
        axis xy
        lab = sprintf('classified as %s',labels(idx(jj)));
        title(lab,'Color','Red');
        pause
    end
end

%% plot the filters (weights)
% Be careful as the following loops will plot all the filters. 

if show.filter
    figh=figure(3);clf;
    set(figh,'Outerposition',[451,41,450,360]);
    
    % Filters from Conv1 layer
    for jj=1:16
        subplot(4,4,jj)
        imagesc(XONet2.Layers(2).Weights(:,:,1,jj))
        set(gca, 'XTickLabel', [])
        set(gca, 'YTickLabel', [])
        axis xy
        colormap(gray);
    end
    subplot(4,4,2)
    title('1 conv layer, weights of filter 1:16');
    
    %%
    % Filters from Conv2 layer
    for filter = 1:32
        figh=figure(20+filter);clf;
        set(figh,'Outerposition',[450*2+1+filter*2,41,450,360]);
        for jj=1:16
            subplot(4,4,jj)
            imagesc(XONet2.Layers(5).Weights(:,:,jj,filter))
            set(gca, 'XTickLabel', [])
            set(gca, 'YTickLabel', [])
            axis xy
            colormap(gray);
        end
        subplot(4,4,2)
        fname = sprintf('2 conv layer, weights of filter %d',filter);
        title(fname);
    end
    
    % Filters from Conv3 layer
    for filter = 1:32
        figh=figure(333+filter);clf;
        set(figh,'Outerposition',[450*3+1+filter*2,41,450,360]);
        for jj=1:32
            subplot(6,6,jj)
            imagesc(XONet2.Layers(8).Weights(:,:,jj,filter))
            set(gca, 'XTickLabel', [])
            set(gca, 'YTickLabel', [])
            axis xy
            colormap(gray);
        end
        subplot(6,6,2)
        fname = sprintf('3 conv layer, weights of filter %d',filter);
        title(fname);
    end
end

%% Plot feature maps for a single examples of each category

if show.feature_maps
    for cats=1:2
        if cats==1
            fig_off = 0;  % figure id offset
            y_offset = 0; % y-position offset
            imds_test = imageDatastore(validationDS.Files(8));  % circle            
        else
            fig_off=100;
            y_offset = 400;
            imds_test = imageDatastore(validationDS.Files(end-1));  % cross            
        end
        figh = figure(65+fig_off);clf;
        set(figh,'Outerposition',[1,800-y_offset,450,400]);
        imagesc(readimage(imds_test,1))
        axis xy
        colormap(gray);
        features_conv1_maxpool = activations(XONet2,imds_test,4,'OutputAs','channels');
        figh= figure(66+fig_off);clf;
        set(figh,'Outerposition',[451,800-y_offset,450,400]);
        for jj = 1:16
            subplot(4,4,jj)
            imagesc(features_conv1_maxpool(:,:,jj))
            set(gca, 'XTickLabel', [])
            set(gca, 'YTickLabel', [])
            axis xy
        end
        features_conv1_maxpool2 = activations(XONet2,imds_test,7,'OutputAs','channels');
        figh=figure(67+fig_off);clf;
        set(figh,'Outerposition',[450*2+1,800-y_offset,450,400]);
        for jj = 1:32
            subplot(6,6,jj)
            imagesc(features_conv1_maxpool2(:,:,jj))
            set(gca, 'XTickLabel', [])
            set(gca, 'YTickLabel', [])
            axis xy
        end
        features_conv1_maxpool3 = activations(XONet2,imds_test,10,'OutputAs','channels');
        figh=figure(68+fig_off);clf;
        set(figh,'Outerposition',[450*3+1,800-y_offset,450,400]);
        for jj = 1:32
            subplot(6,6,jj)
            imagesc(features_conv1_maxpool3(:,:,jj))
            set(gca, 'XTickLabel', [])
            set(gca, 'YTickLabel', [])
            axis xy
        end
        features_fc = activations(XONet2,imds_test,11,'OutputAs','channels');
        figh=figure(69+fig_off);clf;
        set(figh,'Outerposition',[450*4+1,800-y_offset,130,400]);
        plot([1,2],[features_fc(1,1,1), features_fc(1,1,2)],'X','Color','red','Linewidth',5)
        %axis([0,3,-5,5])
    end
end
